apt install openswan ppp xl2tpd


ipsec配置文件监听IP：/etc/ipsec.conf
ipsec共享秘钥文件：/etc/ipsec.secrets
用户名和密码：/etc/ppp/chap-secrets
xl2tpd配置文件：/etc/xl2tpd/xl2tpd.conf
设置dns：/etc/ppp/options.xl2tpd


/etc/sysctl.conf
net.ipv4.ip_forward = 1
net.ipv4.conf.default.rp_filter = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
net.ipv4.conf.all.log_martians = 0
net.ipv4.conf.default.log_martians = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.icmp_ignore_bogus_error_responses = 1


service xl2tpd restart
ipsec setup restart 
chkconfig ipsec on
ipsec verify
sysctl -p