# IRC
* 关于irc配置文件
* 团队使用INSPIRCD来搭建匿名聊天服务
* INSPIRCD已经开发到4版本
* 现在只更新INSPIRCD4+版本的配置文件
* INSPIRCD3已成为稳定的历史
* 您可以去历史中寻找v3的配置文件
* 后续更新依旧